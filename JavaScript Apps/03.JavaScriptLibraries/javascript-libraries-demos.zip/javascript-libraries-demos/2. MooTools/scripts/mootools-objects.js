var Person = new Class({
  initialize: function(fname, lname) {
    this.fname = fname;
    this.lname = lname;
  },
  fullname: function() {
    return this.fname + " " + this.lname;
  }
});

var Jedi = new Class({
  Extends: Person,
  initialize: function(fname, lname, specialization) {
    this.parent(fname, lname);
    this.specialization = specialization;
  }
});

var obiWan = new Jedi("Obi Wan", "Kenobi", "sentinel");

console.log(obiWan.fullname());