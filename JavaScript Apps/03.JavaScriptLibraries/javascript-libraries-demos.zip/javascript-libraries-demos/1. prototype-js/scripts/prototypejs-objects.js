var Person = Class.create({
  initialize: function(fname, lname) {
    this.fname = fname;
    this.lname = lname;
  },
  fullName: function() {
    return this.fname + " " + this.lname;
  }
});

var Ninja = Class.create(Person, {
  initialize: function($super, attack) {
    $super("Unknown", "Unknown");
    this.attack = attack;
  },
  fight: function() {
    return "The ninja has an attack of " + this.attack;
  }
});

var kidNinja = new Ninja(15);

console.log(kidNinja.fullName());
console.log(kidNinja.fight())