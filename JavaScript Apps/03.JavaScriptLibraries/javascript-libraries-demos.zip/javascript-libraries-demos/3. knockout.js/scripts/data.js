[{
    firstName: "Anakin",
    lastName: "Skywalker"
  },
  {
    firstName: "Obi Wan",
    lastName: "Kenobi"
  },
  {
    firstName: "Han",
    lastName: "Solo"
  }
]