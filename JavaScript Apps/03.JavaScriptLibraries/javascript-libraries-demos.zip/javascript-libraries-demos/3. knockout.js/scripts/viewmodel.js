var data = [{
    firstName: "Anakin",
    lastName: "Skywalker",
    specialization: "Sentinel"
  }, {
    firstName: "Obi Wan",
    lastName: "Kenobi",
    specialization: "Sentinel"
  }, {
    firstName: "Obi Wan",
    lastName: "Kenobi",
    specialization: "Sentinel"
  }
];

var Person = Class.create({
  init: function(fname, lname) {
    this.fname = ko.observable(fname);
    this.lname = ko.observable(lname);
    this.fullname = ko.computed(function() {
      return this.fname() + " " + this.lname();
    }, this);
  }
});

var vm = {
  people: ko.observableArray([]),
  selectedItem: ko.observable()
};
vm.addPerson = function(fname, lname) {
  var newPerson = new Person(fname, lname);
  vm.people.push(newPerson);
};
vm.changeSelected = function(item) {
  vm.selectedItem(item);
}

$(document).ready(function() {
  for (var i = 0; i < data.length; i++) {
    var item = data[i];
    vm.addPerson(item.firstName, item.lastName);
  }
  vm.changeSelected(0);

  ko.applyBindings(vm);
});