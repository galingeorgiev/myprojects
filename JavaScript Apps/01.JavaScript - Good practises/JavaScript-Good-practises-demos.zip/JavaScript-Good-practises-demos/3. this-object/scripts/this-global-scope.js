
console.log("this === window? -> " + (this === window));
this.message = "Well done!";
var errorMessage = "Error happened";
console.log(message);
console.log(this.errorMessage);