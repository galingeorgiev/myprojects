function() {
  'use strict';
  console.log(Object.prototype);
  delete Object.prototype;
}());