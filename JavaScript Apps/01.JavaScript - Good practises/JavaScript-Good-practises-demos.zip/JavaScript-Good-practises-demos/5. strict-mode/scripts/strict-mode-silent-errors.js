(function(){  
  'use strict';
  document = {};
}());