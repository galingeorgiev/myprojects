function something(){
  'use strict';
  this.message = "asdasd";
}

something();